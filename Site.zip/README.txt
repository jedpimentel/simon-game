Clone of the classic "Simon" game
https://en.wikipedia.org/wiki/Simon_(game)

Done as part of the Free Code Camp curriculum.
Problem statement: http://www.freecodecamp.com/challenges/build-a-simon-game


	225 Hz
	195 Hz
	147 Hz
	112 Hz
	
to do:
	"free press" button
	disable selection within the button area
	http://www.sitepoint.com/5-ways-prevent-300ms-click-delay-mobile-devices/
	
MODES:
	Normal - Miss a beat and get another chance.
	Strict - Miss a beat and start from scratch.
	Zen    - Free play. Have fun with the cool sounds.
	

Jose Eduardo Pimentel
/jedpimentel



note: watch national lampoons vacation the remake
