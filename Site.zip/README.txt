Clone of the classic "Simon" game
https://en.wikipedia.org/wiki/Simon_(game)

Done as part of the Free Code Camp curriculum.
Problem statement: http://www.freecodecamp.com/challenges/build-a-simon-game
	
MODES:
	Normal - Miss a beat and get another chance.
	Strict - Miss a beat and start from scratch.
	Zen    - Free play. Have fun with the cool sounds.
	
to do:
	http://www.sitepoint.com/5-ways-prevent-300ms-click-delay-mobile-devices/
	issue: slow on mobile (Lumia 640);
	stop trying to add features before basic app is ready
	

Jose Eduardo Pimentel
/jedpimentel
